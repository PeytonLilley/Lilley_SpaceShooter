﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour
{
    private void Update()
    {
    }

}
